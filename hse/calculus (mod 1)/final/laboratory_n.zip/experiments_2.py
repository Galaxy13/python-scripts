import numpy as np
import pandas as pd
from matplotlib import pyplot as plt

datX=np.load('x_train.npy')
datY=np.log(np.load('y_train.npy'))
datX=pd.DataFrame(datX, columns=datX.dtype.names)

to_drop = ['date',
           'sqft_lot',
           'waterfront',
           'yr_built',
           'yr_renovated',
           'zipcode']
X=datX[['bedrooms',
       'bathrooms',
        'sqft_living',
        'floors',
        'condition',
        'grade',
        'sqft_above',
        'sqft_basement',
        'long',
        'lat']]
N=X.shape[0]
m=X.shape[1]

X = pd.concat([pd.Series(1, index=X.index, name='00'), X], axis=1)

def loss(w, X, y):
    lossValue = np.sum((X.dot(w) - y) ** 2) / N
    return lossValue

def grad(w_k, X, y):
    loss_n = X.dot(w_k) - y
    lossGradient_n = X.T.dot(loss_n) / N
    return np.array(lossGradient_n)


def gradDescent(w_init, alpha, X, y, maxiter=1500, eps=1e-2):
    losses = []
    weights = [w_init]

    w_k = weights[-1]

    # your code goes here
    for d in range(maxiter):
        w_k = w_k - alpha * grad(w_k, X, y)
        lossValue_k = loss(w_k, X, y)
        w_k_length = np.linalg.norm(w_k)
        if w_k_length < eps:
            break
        weights.append(w_k)
        losses.append(lossValue_k)

    return weights, losses

plt.figure(figsize=(8,8))
print(X.loc[23])

#
# w_init = np.linspace(0, 1, 11)
# weights, losses = gradDescent(w_init, 1e-9, X, datY)
# plt.plot(range(len(losses)), losses)
# plt.xlabel('Number of Iterations')
# plt.ylabel('Losses')
# plt.legend()
# plt.show()

